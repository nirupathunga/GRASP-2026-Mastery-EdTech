import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def get_blooms_assessment(md_text):
    """Analyzes text and maps it to Bloom's Taxonomy levels."""
    prompt = f"""
    Analyze the following educational content and map it to Bloom's Taxonomy levels:
    CONTENT: {md_text}
    
    Return a structured summary of topics. For each topic, identify the primary Bloom's level.
    """
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

def audit_reasoning(transcript, topic_id):
    """
    The 'Mastery Audit': Compares student voice transcript against the topic requirements.
    Returns a JSON object with score and feedback.
    """
    prompt = f"""
    You are an expert academic evaluator. Audit the student's understanding of Topic ID: {topic_id}.
    STUDENT TRANSCRIPT: "{transcript}"
    
    Evaluate based on:
    1. Conceptual accuracy (Facts).
    2. Logical depth (Reasoning).
    3. Completeness (Gaps).
    
    You MUST return ONLY a JSON object with these keys:
    {{
        "score": (integer 0-100),
        "feedback": "Specific guidance on what they missed or got right",
        "mastery_attained": (boolean)
    }}
    """
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"}
    )
    # Parse the JSON string into a Python dictionary
    return json.loads(response.choices[0].message.content)

def get_adaptive_instruction(topic_id, previous_feedback=None):
    """
    The 'Adaptive Loop': If they fail, generate a new explanation 
    using a different analogy based on their specific mistake.
    """
    prompt = f"""
    The student failed to master Topic: {topic_id}.
    Their previous feedback was: "{previous_feedback}"
    
    Provide a NEW, simplified explanation of this topic. 
    Use a fresh analogy and focus specifically on correcting the misunderstanding mentioned in the feedback.
    Keep the tone encouraging.
    """
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content